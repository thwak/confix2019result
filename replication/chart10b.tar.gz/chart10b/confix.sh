/usr/bin/java -Xmx4g -cp ../lib/las.jar:../lib/confix-ami.jar -Duser.language=en -Duser.timezone=America/Los_Angeles com.github.thwak.confix.main.ConFix
